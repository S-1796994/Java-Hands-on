package com.practice2;

public class Rectangle extends Shape {
	public double length;
	public double width;
	
	public Rectangle(double length, double width) {
		super();
		this.length = length;
		this.width = width;
	}

	@Override
	public double getArea() {
		return length*width;

	}
	
	public static void main(String[] args) {
		Rectangle rectangle=new  Rectangle(5,3);
		double area=rectangle.getArea();
		System.out.println("Area of Rectangle: " +area);
	}

}
