package com.practice2;

import java.util.ArrayList;
import java.util.List;

public class StringTrimmer {
	
	public static void trimData(List<String> data) {
		data.replaceAll(String::trim);
	}

	public static void main(String[] args) {
		List<String> strings=new ArrayList<>();
		strings.add(" Hello ");
		strings.add("         welcome ");
		strings.add("java ");
		System.out.println("Before trimming : " + strings);
		trimData(strings);
		System.out.println("After trimming : " +strings);
		
	}
}
