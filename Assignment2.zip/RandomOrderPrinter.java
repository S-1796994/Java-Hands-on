package com.practice2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RandomOrderPrinter {
	
	public static void main(String[] args) {
		List<String> arguments=Arrays.asList(args);
		Collections.shuffle(arguments);
		
		//traditional enhanced loop
		System.out.println("Traditional enhanced For Loop");
		for(String arg:arguments) {
			System.out.println(arg);
		}
		
		//Using Stream
		System.out.println();
		System.out.println("Stream Loop");
		arguments.stream().forEach(System.out::println);
		
	}

}
