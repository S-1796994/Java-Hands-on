package com.practice2;

public class Shape {
	
	public double getArea() {
		return 0.0;		
	}

}
