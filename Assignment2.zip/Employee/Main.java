package com.practice2.Employee;

public class Main {
	
	public static void main(String[] args ) {
		Manager manager=new Manager("John","897 Main st",80000,"manager");
		Developer developer=new Developer("David","2nd street",40000,"java developer");
		Programmer programmer=new Programmer("David","2nd street",50000,"programmer");
		
		double mangerBonus=manager.calculateBonus();
		double developerBonus=developer.calculateBonus();
		double programmerBonus=programmer.calculateBonus();
		
		System.out.println("Manager Bonus $"+mangerBonus);
		System.out.println("Developer Bonus $"+developerBonus );
		System.out.println("Programmer Bonus $"+programmerBonus );
	}
	

}
