package com.practice2.Employee;

public class Developer extends Employee{

	public Developer(String name, String address, double salary, String jobTitle) {
		super(name, address, salary, jobTitle);
	}
	
	@Override
	public double calculateBonus() {
		return salary*0.1;
	}

}
