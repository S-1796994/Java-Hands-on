package com.practice2.Employee;

public class Employee {
	protected String name;
	protected String address;
	protected double salary;
	protected String jobTitle;
	
	public Employee(String name,String address,double salary,String jobTitle) {
		this.name=name;
		this.address=address;
		this.salary=salary;
		this.jobTitle=jobTitle;
	}
	
	public double calculateBonus() {
		return 0.0;
	}
	
	public String generatePerformanceReport() {
		return "Performance Report";
	}
	
	public void manageProject(String projectName) {
		System.out.println("Managing project: "+projectName);
	}

}
